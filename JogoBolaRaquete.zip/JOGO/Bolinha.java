import java.awt.Color;
import java.awt.Graphics;

public class Bolinha {
    int x; 
    int y;
    int velX;
    int velY;

    final int DIAMETRO = 30;

    public Bolinha(int x, int y, int velX, int velY) {
        this.x = 500;
        this.y = y;
        this.velX = 5;
        this.velY = velY;
    }

    public void mover() {
        x += velX;
        y += velY;
    }

    public void ColisaoBorda(int largura, int altura) {

        if (x <= 0 || x >= largura - DIAMETRO) {
            velX = -velX;  
        }

        if (y <= 0 || y >= altura - DIAMETRO) {
            velY = -velY; 
        }
    }
    public boolean ColisaoRaquete(Raquete raquete) {
        if (x <= 30 && y + DIAMETRO >= raquete.y && y <= raquete.y + raquete.ALTURA) {
            velX = -velX;  
        }
        return false;
    }

    public void desenhar(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillOval(x, y, DIAMETRO, DIAMETRO);
    }
}
