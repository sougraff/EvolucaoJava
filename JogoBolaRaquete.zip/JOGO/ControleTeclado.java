import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ControleTeclado extends KeyAdapter {
    private Raquete raquete;
    private Bolinha bolinha;

    public ControleTeclado(Raquete raquete, Bolinha bolinha) {
        this.raquete = raquete;
        this.bolinha = bolinha;
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP) raquete.mover(-10);
        if (e.getKeyCode() == KeyEvent.VK_DOWN) raquete.mover(10);

    }
}
