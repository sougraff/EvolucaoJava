import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Jogo extends JPanel {
    private Bolinha bolinha;
    private Raquete raquete;
    private Image imagemfundo;

    public Jogo() {
        this.bolinha = new Bolinha(300, 300, 4, 4);
        this.raquete = new Raquete(250);

        imagemfundo = Toolkit.getDefaultToolkit().getImage("istockphoto-479545387-612x612.jpg");

        setBackground(Color.BLACK);
        ControleTeclado controleTeclado = new ControleTeclado(raquete, bolinha);
        addKeyListener(controleTeclado);
        setFocusable(true);
    }

    public static void main(String[] args) {
        JFrame janela = new JFrame("Roland Garros");
        Jogo painel = new Jogo();

        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setSize(600, 600);
        janela.setLocation(500, 150);
        janela.setResizable(false);
        janela.add(painel);
        janela.setVisible(true);

        while (true) {
            painel.atualizar();
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(imagemfundo, 0, 0, getWidth(), getHeight(), this);

        bolinha.desenhar(g);
        raquete.desenhar(g);
    }

    public void atualizar() {
        bolinha.mover();
        bolinha.ColisaoBorda(getWidth(), getHeight());
        bolinha.ColisaoRaquete(raquete);
        repaint();
    }
}
