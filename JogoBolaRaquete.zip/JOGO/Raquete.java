import java.awt.Color;
import java.awt.Graphics;

public class Raquete {
    int y;
    final int LARGURA = 20, ALTURA = 100;
    final int LIMITESuperior = 0;  // Limite superior para a raquete (topo da tela)
    final int LIMITEInferior = 570; // Limite inferior para a raquete (parte de baixo da tela)
    
    public Raquete(int y) {
        this.y = y;
    }

    // Método para mover a raquete
    public void mover(int direcao) {
        // Verifica se a raquete vai ultrapassar o topo ou a parte inferior
        if (direcao < 0 && y > LIMITESuperior) {
            y += direcao; // Movimento para cima
        } else if (direcao > 0 && y < LIMITEInferior - ALTURA) {
            y += direcao; // Movimento para baixo
        }
    }

    // Método para desenhar a raquete
    public void desenhar(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(10, y, LARGURA, ALTURA); // Desenha a raquete
    }
}
